import cv2
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical

# Constants
IMG_SIZE = 64  # Resize images to 64x64
NUM_CLASSES = 26  # A to Z
DATASET_PATH = "mydata"
MODEL_PATH = "sign_language_model.h5"

# 1. Load and preprocess dataset
def load_dataset():
    images = []
    labels = []
    class_names = sorted(os.listdir(DATASET_PATH))  # A to Z
    for class_idx, class_name in enumerate(class_names):
        class_path = os.path.join(DATASET_PATH, class_name)
        for img_name in os.listdir(class_path):
            img_path = os.path.join(class_path, img_name)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)  # Grayscale for simplicity
            if img is not None:
                img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
                images.append(img)
                labels.append(class_idx)
    
    # Convert to numpy arrays
    images = np.array(images).reshape(-1, IMG_SIZE, IMG_SIZE, 1) / 255.0  # Normalize
    labels = to_categorical(labels, NUM_CLASSES)  # One-hot encoding
    return images, labels, class_names

# 2. Build CNN model
def build_model():
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(IMG_SIZE, IMG_SIZE, 1)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),
        Dense(NUM_CLASSES, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# 3. Train or load model
def train_or_load_model():
    if os.path.exists(MODEL_PATH):
        print("Loading existing model...")
        return tf.keras.models.load_model(MODEL_PATH)
    
    print("Training new model...")
    images, labels, class_names = load_dataset()
    X_train, X_val, y_train, y_val = train_test_split(images, labels, test_size=0.2, random_state=42)
    
    model = build_model()
    model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_val, y_val))
    model.save(MODEL_PATH)
    return model

# 4. Preprocess webcam frame
def preprocess_frame(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
    normalized = resized.reshape(1, IMG_SIZE, IMG_SIZE, 1) / 255.0
    return normalized

# 5. Real-time sign language detection
def main():
    model = train_or_load_model()
    class_names = sorted(os.listdir(DATASET_PATH))
    
    cap = cv2.VideoCapture(0)  # Open webcam
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return
    
    current_word = ""
    last_letter = ""
    letter_stable_count = 0
    STABLE_THRESHOLD = 10  # Frames to confirm a letter
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Define ROI (Region of Interest) for hand detection
        roi = frame[100:300, 100:300]  # Adjust as needed
        cv2.rectangle(frame, (100, 100), (300, 300), (0, 255, 0), 2)
        
        # Preprocess and predict
        processed_frame = preprocess_frame(roi)
        prediction = model.predict(processed_frame)
        predicted_class = np.argmax(prediction, axis=1)[0]
        predicted_letter = class_names[predicted_class]
        
        # Letter stabilization logic
        if predicted_letter == last_letter:
            letter_stable_count += 1
        else:
            letter_stable_count = 0
            last_letter = predicted_letter
        
        if letter_stable_count >= STABLE_THRESHOLD:
            if predicted_letter not in current_word:
                current_word += predicted_letter
                letter_stable_count = 0  # Reset to avoid repeated additions
        
        # Display results
        cv2.putText(frame, f"Letter: {predicted_letter}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, f"Word: {current_word}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        
        cv2.imshow("Sign Language to Text", frame)
        
        # Press 'q' to quit, 'space' to reset word
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord(' '):
            current_word = ""
    
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
